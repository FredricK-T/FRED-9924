﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace EstherRestaurantSystem
{
    public partial class AdminAddProducts : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\frede\Documents\esther.mdf;Integrated Security=True;Connect Timeout=30");

        public AdminAddProducts()
        {
            InitializeComponent();
            displayData();
        }

        public bool emptyFields()
        {
            if (string.IsNullOrEmpty(adminAddProducts_id.Text) || string.IsNullOrEmpty(adminAddProducts_name.Text)
                || adminAddProducts_type.SelectedIndex == -1 || string.IsNullOrEmpty(adminAddProducts_stock.Text)
                || string.IsNullOrEmpty(adminAddProducts_price.Text) || adminAddProducts_status.SelectedIndex == -1
                || adminProducts_imageView.Image == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void displayData()
        {
            try
            {
                connect.Open();
                string selectQuery = "SELECT * FROM products";
                SqlCommand command = new SqlCommand(selectQuery, connect);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving product data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connect.State == ConnectionState.Open)
                {
                    connect.Close(); // Close the connection here
                }
            }
        }

        private void adminAddUsers_importBtn_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Image Files (*.jpg; *.png)|*.jpg;*.png";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string imagePath = dialog.FileName;
                    adminProducts_imageView.ImageLocation = imagePath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void adminAddProducts_addBtn_Click(object sender, EventArgs e)
        {
            if (emptyFields())
            {
                MessageBox.Show("All fields are required to be filled.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    connect.Open();

                    // Check if the product id already exists
                    string selectProdID = "SELECT * FROM products WHERE prod_id = @prodID";
                    using (SqlCommand selectPID = new SqlCommand(selectProdID, connect))
                    {
                        selectPID.Parameters.AddWithValue("@prodID", adminAddProducts_id.Text.Trim());
                        SqlDataAdapter adapter = new SqlDataAdapter(selectPID);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        if (table.Rows.Count >= 1)
                        {
                            MessageBox.Show("Product ID: " + adminAddProducts_id.Text.Trim() + " is already taken.", "Error Message",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            string insertData = "INSERT INTO products(prod_id, prod_name, prod_type, prod_stock, prod_price, prod_status, prod_image, date_insert) " +
                                "VALUES(@prodID, @prodName, @prodType, @prodStock, @prodPrice, @prodStatus, @prodImage, @prodInsert)";

                            DateTime today = DateTime.Today;
                            string imagePath = Path.Combine(@"C:\Users\frede\Desktop\MyCode\EstherRestaurantSystem\EstherRestaurantSystem\Product_Directory\",
                                adminAddProducts_id.Text.Trim() + ".jpg");

                            if (!File.Exists(imagePath))
                            {
                                File.Copy(adminProducts_imageView.ImageLocation, imagePath);
                            }

                            using (SqlCommand cmd = new SqlCommand(insertData, connect))
                            {
                                cmd.Parameters.AddWithValue("@prodID", adminAddProducts_id.Text.Trim());
                                cmd.Parameters.AddWithValue("@prodName", adminAddProducts_name.Text.Trim());
                                cmd.Parameters.AddWithValue("@prodType", adminAddProducts_type.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@prodStock", adminAddProducts_stock.Text.Trim());
                                cmd.Parameters.AddWithValue("@prodPrice", adminAddProducts_price.Text.Trim());
                                cmd.Parameters.AddWithValue("@prodStatus", adminAddProducts_status.SelectedItem.ToString());
                                cmd.Parameters.AddWithValue("@prodImage", imagePath);
                                cmd.Parameters.AddWithValue("@prodInsert", today);

                                cmd.ExecuteNonQuery();

                                clearFields();
                            }

                            MessageBox.Show("Huray Product added successfully🥳!", "Success Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            displayData();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close(); // Close the connection here
                    }
                }
            }
        }

        private void clearFields()
        {
            adminAddProducts_id.Text = "";
            adminAddProducts_name.Text = "";
            adminAddProducts_type.SelectedIndex = -1;
            adminAddProducts_stock.Text = "";
            adminAddProducts_price.Text = "";
            adminAddProducts_status.SelectedIndex = -1;
            adminProducts_imageView.Image = null;
        }

        private void adminAddProducts_updateBtn_Click(object sender, EventArgs e)
        {
            if (emptyFields())
            {
                MessageBox.Show("All fields are required to be filled", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult check = MessageBox.Show("Are you sure want to Update Product ID:" + adminAddProducts_id.Text.Trim() +
                    "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (check == DialogResult.Yes)
                {
                    try
                    {
                        connect.Open();

                        string updateData = "UPDATE products set prod_name = @prodName" +
                            ", prod_type = @prodType, prod_stock = @prodStock, prod_price = @prodPrice, prod_status = @prodStatus"
                            + ", date_update = @dateUpdate WHERE prod_id = @prodID";
                        DateTime today = DateTime.Today;

                        using (SqlCommand update = new SqlCommand(updateData, connect))
                        {
                            update.Parameters.AddWithValue("@prodName", adminAddProducts_name.Text.Trim());
                            update.Parameters.AddWithValue("@prodType", adminAddProducts_type.Text.Trim());
                            update.Parameters.AddWithValue("@prodStock", adminAddProducts_stock.Text.Trim());
                            update.Parameters.AddWithValue("@prodPrice", adminAddProducts_price.Text.Trim());
                            update.Parameters.AddWithValue("@prodStatus", adminAddProducts_status.Text.Trim());
                            update.Parameters.AddWithValue("@dateUpdate", today);
                            update.Parameters.AddWithValue("@prodID", adminAddProducts_id.Text.Trim());

                            update.ExecuteNonQuery();

                            displayData();
                            MessageBox.Show("Updated successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        if (connect.State == ConnectionState.Open)
                        {
                            connect.Close();
                        }
                    }
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                adminAddProducts_id.Text = row.Cells[1].Value.ToString();
                adminAddProducts_name.Text = row.Cells[2].Value.ToString();
                adminAddProducts_type.Text = row.Cells[3].Value.ToString();
                adminAddProducts_stock.Text = row.Cells[4].Value.ToString();
                adminAddProducts_price.Text = row.Cells[5].Value.ToString();
                adminAddProducts_status.Text = row.Cells[6].Value.ToString();

                string imagePath = row.Cells[7].Value.ToString();

                try
                {
                    if (!string.IsNullOrEmpty(imagePath))
                    {
                        adminProducts_imageView.Image = Image.FromFile(imagePath);
                    }
                    else
                    {
                        adminProducts_imageView.Image = null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading image: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void adminAddProducts_deleteBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(adminAddProducts_id.Text))
            {
                MessageBox.Show("Please select a product to delete.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this product?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        connect.Open();
                        string deleteQuery = "DELETE FROM products WHERE prod_id = @prodID";
                        using (SqlCommand command = new SqlCommand(deleteQuery, connect))
                        {
                            command.Parameters.AddWithValue("@prodID", adminAddProducts_id.Text.Trim());
                            command.ExecuteNonQuery();
                            MessageBox.Show("Product deleted successfully!", "Success Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            displayData(); // Refresh the data grid view after deletion
                            clearFields(); // Clear the fields after deletion
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting product: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        if (connect.State == ConnectionState.Open)
                        {
                            connect.Close();
                        }
                    }
                }
            }
        }

        private void adminAddProducts_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }
    }
}



