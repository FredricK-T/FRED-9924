﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EstherRestaurantSystem
{
    public partial class AdminAddUsers : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\frede\Documents\esther.mdf;Integrated Security=True;Connect Timeout=30");
        private int id = 0;

        public AdminAddUsers()
        {
            InitializeComponent();
            DisplayAddUserData();
        }

        public void DisplayAddUserData()
        {
            try
            {
                if (connect.State != ConnectionState.Open)
                    connect.Open();

                string selectData = "SELECT * FROM users";
                SqlCommand cmd = new SqlCommand(selectData, connect);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving user data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connect.State == ConnectionState.Open)
                    connect.Close();
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // No action defined for this event
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // No action defined for this button
        }

        public bool EmptyFields()
        {
            if (string.IsNullOrEmpty(adminAddUsers_username.Text) || string.IsNullOrEmpty(adminAddUsers_password.Text)
                || string.IsNullOrEmpty(adminAddUsers_role.Text) || string.IsNullOrEmpty(adminAddUsers_status.Text)
                || adminAddUsers_ImageView.Image == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void adminAddUsers_addBtn_Click(object sender, EventArgs e)
        {
            if (EmptyFields())
            {
                MessageBox.Show("Sorry, all fields are required to be filled", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                if (connect.State != ConnectionState.Open)
                    connect.Open();

                // Check if username already exists
                string selectUsern = "SELECT * FROM users WHERE username = @usern";
                using (SqlCommand checkUsern = new SqlCommand(selectUsern, connect))
                {
                    checkUsern.Parameters.AddWithValue("@usern", adminAddUsers_username.Text.Trim());
                    SqlDataAdapter adapter = new SqlDataAdapter(checkUsern);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    if (table.Rows.Count >= 1)
                    {
                        MessageBox.Show(adminAddUsers_username.Text + " is already taken", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // Insert new user data into the database
                string insertData = "INSERT INTO users (username, password, profile_image, role, status, date_reg) " +
                    "VALUES(@usern, @pass, @image, @role, @status, @date)";
                DateTime today = DateTime.Today;

                string path = Path.Combine(@"C:\Users\frede\Desktop\MyCode\EstherRestaurantSystem\EstherRestaurantSystem\User_Directory\", adminAddUsers_username.Text.Trim() + ".jpg");
                string directoryPath = Path.GetDirectoryName(path);
                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                File.Copy(adminAddUsers_ImageView.ImageLocation, path, true);

                using (SqlCommand cmd = new SqlCommand(insertData, connect))
                {
                    string usern = adminAddUsers_username.Text.Substring(0, 1).ToUpper() + adminAddUsers_username.Text.Substring(1);
                    cmd.Parameters.AddWithValue("@usern", usern);
                    cmd.Parameters.AddWithValue("@pass", adminAddUsers_password.Text.Trim());
                    cmd.Parameters.AddWithValue("@image", path);
                    cmd.Parameters.AddWithValue("@role", adminAddUsers_role.Text.Trim());
                    cmd.Parameters.AddWithValue("@status", adminAddUsers_status.Text.Trim());
                    cmd.Parameters.AddWithValue("@date", today);

                    cmd.ExecuteNonQuery();
                    clearFields();

                    MessageBox.Show("Added successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    DisplayAddUserData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection failed: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connect.State == ConnectionState.Open)
                    connect.Close();
            }
        }

        private void adminAddUsers_importBtn_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Image Files (*.jpg; *.png|*.jpg;*.png)";

                string imagePath = "";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    imagePath = dialog.FileName;
                    adminAddUsers_ImageView.ImageLocation = imagePath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                id = Convert.ToInt32(row.Cells["id"].Value); // Assuming the primary key column is named "id"
                adminAddUsers_username.Text = row.Cells["username"].Value.ToString();
                adminAddUsers_password.Text = row.Cells["password"].Value.ToString();
                adminAddUsers_role.Text = row.Cells["role"].Value.ToString();
                adminAddUsers_status.Text = row.Cells["status"].Value.ToString();

                string imagePath = row.Cells["profile_image"].Value.ToString();

                try
                {
                    if (imagePath != null)

                        if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                        {
                            adminAddUsers_ImageView.Image = Image.FromFile(imagePath);
                        }
                        else
                        {
                            adminAddUsers_ImageView.Image = null;
                        }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Image :3", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void adminAddUsers_Update_Click(object sender, EventArgs e)
        {
            if (EmptyFields())
            {
                MessageBox.Show("All fields are required to be filled.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                DialogResult result = MessageBox.Show("Are you sure you want to update Username: " + adminAddUsers_username.Text.Trim()
                    + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        if (connect.State != ConnectionState.Open)
                            connect.Open();

                        string updateData = "UPDATE users SET username = @usern, password = @pass, role = @role, status = @status WHERE id = @id";

                        using (SqlCommand cmd = new SqlCommand(updateData, connect))
                        {
                            string usern = adminAddUsers_username.Text.Substring(0, 1).ToUpper() + adminAddUsers_username.Text.Substring(1);
                            cmd.Parameters.AddWithValue("@usern", usern);
                            cmd.Parameters.AddWithValue("@pass", adminAddUsers_password

.Text.Trim());
                            cmd.Parameters.AddWithValue("@role", adminAddUsers_role.Text.Trim());
                            cmd.Parameters.AddWithValue("@status", adminAddUsers_status.Text.Trim());
                            cmd.Parameters.AddWithValue("@id", id);

                            cmd.ExecuteNonQuery();

                            clearFields();

                            MessageBox.Show("Updated successfully 😊👍!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            DisplayAddUserData();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Sorry Connection failed: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        if (connect.State == ConnectionState.Open)
                            connect.Close();
                    }
                }
            }
        }

        public void clearFields()
        {
            adminAddUsers_username.Text = "";
            adminAddUsers_password.Text = "";
            adminAddUsers_role.SelectedIndex = -1;
            adminAddUsers_status.SelectedIndex = -1;
            adminAddUsers_ImageView.Image = null;

        }

        private void adminAddUsers_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void adminAddUsers_deleteBtn_Click(object sender, EventArgs e)
        {

            try
            {
                if (EmptyFields())
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this user?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        if (connect.State != ConnectionState.Open)
                            connect.Open();

                        string deleteData = "DELETE FROM users WHERE id = @id";

                        using (SqlCommand cmd = new SqlCommand(deleteData, connect))
                        {
                            cmd.Parameters.AddWithValue("@id", id);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("User deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                DisplayAddUserData();
                            }
                            else
                            {
                                MessageBox.Show("User not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("All fields are required to be filled.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connect.State == ConnectionState.Open)
                    connect.Close();
            }
        }
    }
}




